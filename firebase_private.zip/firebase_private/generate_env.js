    // generate_env.js
    // This script generates the complete .env file content and writes it directly.

    const fs = require('fs');
    const path = require('path');

    // --- IMPORTANT: REPLACE THIS PATH ---
    // This should be the path to the JSON file you downloaded from Firebase.
    // Example: './your-firebase-project-key.json' if it's in the same directory
    // or 'C:/Users/YourUser/Downloads/your-firebase-project-key.json'
    const firebaseKeyFilePath = 'C:/Users/PC/Downloads/t-level revision site base/revision-website-465717-firebase-adminsdk-fbsvc-9cf01e3306.json';

    // --- YOUR GOOGLE_CLIENT_ID ---
    // This is the Client ID for your web application from Google Cloud Console.
    const googleClientId = "805206297313-pk485lau3ldgemv2tspqtpful0u272al.apps.googleusercontent.com";

    async function writeEnvFile() {
        const envFilePath = path.join(__dirname, '.env'); // Path to the .env file in the current directory

        try {
            // Read the raw JSON content of the Firebase key file
            const rawJsonContent = fs.readFileSync(firebaseKeyFilePath, 'utf8');

            // Parse it to ensure it's valid JSON
            const parsedJson = JSON.parse(rawJsonContent);

            // Stringify it back to a single line, which automatically escapes internal quotes and newlines
            const escapedFirebaseKey = JSON.stringify(parsedJson);

            // Construct the full .env content
            const envContent = `GOOGLE_CLIENT_ID="${googleClientId}"\nFIREBASE_SERVICE_ACCOUNT_KEY='${escapedFirebaseKey}'\n`;

            // Write the content directly to the .env file
            fs.writeFileSync(envFilePath, envContent, 'utf8');

            console.log('Successfully generated and wrote .env file!');
            console.log('You can now run: npm start');

        } catch (error) {
            console.error('Error generating or writing .env file:');
            console.error('Please ensure the firebaseKeyFilePath is correct and the JSON file is valid.');
            console.error(error);
        }
    }

    writeEnvFile();
    