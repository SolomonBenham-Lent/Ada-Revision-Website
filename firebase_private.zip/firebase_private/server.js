    // server.js

    // Load environment variables from .env file
    require('dotenv').config();

    // Import necessary modules
    const express = require('express');
    const { OAuth2Client } = require('google-auth-library');
    const admin = require('firebase-admin');

    // --- Firebase Initialization ---
    // Parse the service account key from the environment variable
    let serviceAccount;

    // --- DEBUG LOG ---
    // console.log('DEBUG: Value of process.env.FIREBASE_SERVICE_ACCOUNT_KEY:', process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
    // --- END DEBUG LOG ---

    try {
      serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
    } catch (e) {
      console.error('Error parsing FIREBASE_SERVICE_ACCOUNT_KEY from .env:', e.message);
      console.error('Please ensure FIREBASE_SERVICE_ACCOUNT_KEY is a valid single-line JSON string.');
      process.exit(1); // Exit if critical config is missing/invalid
    }

    // Initialize Firebase Admin SDK
    try {
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
      });
      console.log('Firebase Admin SDK initialized successfully.');
    } catch (error) {
      console.error('Error initializing Firebase Admin SDK:', error.message);
      process.exit(1);
    }

    const db = admin.firestore(); // Get a reference to the Firestore database

    // --- Google OAuth2 Client for ID Token Verification ---
    const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
    if (!GOOGLE_CLIENT_ID) {
      console.error('GOOGLE_CLIENT_ID is not set in .env file.');
      process.exit(1);
    }
    const client = new OAuth2Client(GOOGLE_CLIENT_ID);

    // --- Express App Setup ---
    const app = express();
    const PORT = process.env.PORT || 3000; // Use port 3000 by default

    // Middleware to parse JSON request bodies
    app.use(express.json());

    // Middleware for CORS (Cross-Origin Resource Sharing)
    // This is crucial to allow your frontend to make requests to this backend.
    app.use((req, res, next) => {
      // In production, replace '*' with your actual frontend domain (e.g., 'https://yourwebsite.com')
      // For local development, you might need to specify the exact localhost port of your frontend.
      // Example: 'http://localhost:5500' if using VS Code Live Server
      res.setHeader('Access-Control-Allow-Origin', '*'); // Temporarily allow all origins for dev
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      if (req.method === 'OPTIONS') {
        return res.sendStatus(200); // Handle preflight requests
      }
      next();
    });

    // --- API Endpoint for Google Sign-In ---
    app.post('/api/google-signin', async (req, res) => {
      const idToken = req.body.idToken;

      if (!idToken) {
        return res.status(400).json({ success: false, message: 'ID token is missing.' });
      }

      try {
        // 1. Verify the ID Token
        const ticket = await client.verifyIdToken({
          idToken: idToken,
          audience: GOOGLE_CLIENT_ID, // Ensure the token's audience matches your client ID
        });

        const payload = ticket.getPayload();
        const googleUserId = payload['sub']; // Google's unique user ID (immutable)
        const email = payload['email'];
        const name = payload['name'];
        const picture = payload['picture'];
        const emailVerified = payload['email_verified'];

        if (!emailVerified) {
          return res.status(401).json({ success: false, message: 'Google email not verified.' });
        }

        // --- Firestore User Profile Storage ---
        // Using a collection structure: /users/{googleUserId}/profile
        // Note: The __app_id global is for Canvas environment. For local, you might use a fixed app ID or omit.
        // For simplicity here, we'll use a fixed 'my_web_app' as the appId for local testing.
        const APP_ID_FOR_LOCAL_TESTING = 'my_web_app'; // Use a fixed ID for local testing
        const userProfileRef = db.collection('artifacts').doc(APP_ID_FOR_LOCAL_TESTING).collection('users').doc(googleUserId).collection('user_profiles').doc('profile');

        // Check if user profile already exists
        const doc = await userProfileRef.get();

        if (doc.exists) {
          // User exists: Update last login time and potentially other mutable fields
          await userProfileRef.update({
            last_login_at: admin.firestore.FieldValue.serverTimestamp(),
            name: name, // Update name in case user changed it on Google
            picture: picture // Update picture URL
          });
          console.log(`User ${email} (${googleUserId}) logged in again.`);
        } else {
          // New user: Create a new user profile
          await userProfileRef.set({
            google_user_id: googleUserId,
            email: email,
            name: name,
            picture: picture,
            created_at: admin.firestore.FieldValue.serverTimestamp(),
            last_login_at: admin.firestore.FieldValue.serverTimestamp(),
            auth_method: 'google',
            // Add any other default user fields here
          });
          console.log(`New user ${email} (${googleUserId}) created.`);
        }

        // --- Respond to Frontend ---
        res.json({
          success: true,
          message: 'Sign-in successful!',
          userId: googleUserId,
          name: name,
          email: email,
          picture: picture
        });

      } catch (error) {
        console.error('Error during Google Sign-In process:', error);
        if (error.code === 'auth/id-token-expired') {
          return res.status(401).json({ success: false, message: 'ID token expired. Please sign in again.' });
        }
        res.status(500).json({ success: false, message: 'Internal server error during authentication.' });
      }
    });

    // --- Simple Root Route (for testing if server is running) ---
    app.get('/', (req, res) => {
      res.send('Backend server is running!');
    });

    // --- Start the Server ---
    app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
      console.log(`Access backend at http://localhost:${PORT}`);
    });
    